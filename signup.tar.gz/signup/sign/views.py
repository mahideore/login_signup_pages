from django.shortcuts import render,redirect
from django.contrib import auth
from django.contrib.auth.models import User



# Create your views here.
def home(request):
    return render(request,'home.html')

def login(request):
    if request.method == "POST":
        #CHECK IF A USER EXITS OR NOT
        uname = request.POST['username']
        pwd = request.POST['password']
        user= auth.authenticate(username=uname,password=pwd)
        if user is not None:
            auth.login(request,user)
            return render(request,'show.html')
        else: 
            return render(request,'home.html',{'error': 'invalid login'})
    else:
        return render(request,'home.html')




def signup(request):
    if request.method == "POST":
        #to creTE  useer
        if request.POST['password'] == request.POST['Repeat_Password']:
            #both pass match
            # now check if a previous user exit
            try:
                user = User.objects.get(username=request.POST['username'])
                return render(request,'signup.html',{'error':'user is allready there'})

            except User.DoesNotExist:
                user = User.objects.create_user(username=request.POST['username'],password=request.POST['password'])
                auth.login(request,user)

                return redirect(home)
        else:
                return render(request,'signup.html',{'error':'Passwords dont match'})
    else:

        return render(request,'signup.html')        

def logout(request):
    auth.logout(home)
    return render(request,'home.html')
